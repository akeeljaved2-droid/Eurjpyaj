import json
import requests
import time

# Load config
with open('config.json') as f:
    config = json.load(f)

TELEGRAM_TOKEN = config["telegram_token"]
CHAT_ID = config["chat_id"]
LOT_SIZE = config["lot_size"]
STOP_LOSS_PIPS = config["stop_loss_pips"]
TAKE_PROFIT_PIPS = config["take_profit_pips"]
pairs = config["pairs"]

def send_telegram(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": message}
    requests.post(url, data=payload)

def check_signals():
    # Placeholder logic (replace with 95% strategy)
    for pair in pairs:
        send_telegram(f"Signal check for {pair['symbol']} | Demand: {pair['demand_zone']} | Breakout: {pair['breakout_zone']}")

if __name__ == "__main__":
    while True:
        check_signals()
        time.sleep(300)  # check every 5 mins
